<?php
// login_unigo.php
header('Content-Type: application/json');
require 'db_config_unigo.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success'=>false, 'message'=>'Método no permitido. Usa POST.']);
    exit;
}

$nombre   = $_POST['nombre']   ?? '';
$password = $_POST['password'] ?? '';

if (empty($nombre) || empty($password)) {
    echo json_encode(['success'=>false, 'message'=>'Faltan nombre o contraseña.']);
    exit;
}

// 1) SELECT ahora INCLUYE foto:
$stmt = $conn->prepare(
    "SELECT id, nombre, email, telefono, foto, contraseña
       FROM usuario
      WHERE nombre = ?"
);
$stmt->bind_param("s", $nombre);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows !== 1) {
    echo json_encode(['success'=>false, 'message'=>'Usuario no encontrado']);
    exit;
}

$stmt->bind_result($id, $nombre_db, $email, $telefono, $foto_url, $password_hash);
$stmt->fetch();

$stmt->close();

// 2) Verificar contraseña (por ejemplo, si la tienes hasheada):
if (!password_verify($password, $password_hash)) {
    echo json_encode(['success'=>false, 'message'=>'Contraseña incorrecta']);
    exit;
}

// 3) Devolver el JSON con el campo foto incluido:
echo json_encode([
    'success'  => true,
    'message'  => 'Login exitoso',
    'id'       => $id,
    'nombre'   => $nombre_db,
    'email'    => $email,
    'telefono' => $telefono,
    'foto'     => $foto_url   // ← Aquí incluyes la URL que guardaste con upload_profile_image_unigo.php
]);

$conn->close();
?>
