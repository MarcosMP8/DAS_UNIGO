<?php
// register_unigo.php
header('Content-Type: application/json');
require 'db_config_unigo.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Método no permitido. Usa POST.']);
    exit;
}

$nombre   = $_POST['nombre']   ?? '';
$email    = $_POST['email']    ?? '';
$password = $_POST['password'] ?? '';
$telefono = $_POST['telefono'] ?? '';

// Validaciones básicas
if (empty($nombre) || empty($email) || empty($password)) {
    echo json_encode(['success' => false, 'message' => 'Faltan campos obligatorios.']);
    exit;
}

// 1. ¿Email ya existe?
$stmt = $conn->prepare("SELECT id FROM usuario WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    echo json_encode(['success' => false, 'message' => 'El correo ya está registrado.']);
    $stmt->close();
    $conn->close();
    exit;
}
$stmt->close();

// 2. Insertar nuevo usuario
$hashed = password_hash($password, PASSWORD_DEFAULT);
$stmt = $conn->prepare(
    "INSERT INTO usuario (nombre, email, contraseña, telefono) 
     VALUES (?, ?, ?, ?)"
);
$stmt->bind_param("ssss", $nombre, $email, $hashed, $telefono);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Registro completado.']);
} else {
    echo json_encode(['success' => false, 'message' => 'Error al registrar usuario.']);
}

$stmt->close();
$conn->close();
?>