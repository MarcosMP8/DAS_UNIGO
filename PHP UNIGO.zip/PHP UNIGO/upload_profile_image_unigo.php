<?php
// upload_profile_image_unigo.php
header('Content-Type: application/json');
require 'db_config_unigo.php';

// 1) Sólo POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Método no permitido. Usa POST.']);
    exit;
}

// 2) Recoger parámetros
$id         = $_POST['id']   ?? '';
$fotoBase64 = $_POST['foto'] ?? '';

// 3) Validar
if (empty($id) || empty($fotoBase64)) {
    echo json_encode(['success' => false, 'message' => 'Faltan id o foto.']);
    exit;
}

// 4) Decodificar base64 (soporta data URI)
$extension = 'jpg';
if (preg_match('/^data:image\/(\w+);base64,/', $fotoBase64, $type)) {
    $extension  = strtolower($type[1]); // png, jpeg, gif...
    $fotoBase64 = substr($fotoBase64, strpos($fotoBase64, ',') + 1);
    if (!in_array($extension, ['jpg', 'jpeg', 'png', 'gif'])) {
        echo json_encode(['success' => false, 'message' => 'Tipo de imagen no soportado.']);
        exit;
    }
}
$fotoBase64 = str_replace(' ', '+', $fotoBase64);
$datosImagen = base64_decode($fotoBase64);
if ($datosImagen === false) {
    echo json_encode(['success' => false, 'message' => 'Imagen inválida.']);
    exit;
}

// 5) Directorio de subida
$uploadDir = __DIR__ . '/imagenes';
if (!is_dir($uploadDir) && !mkdir($uploadDir, 0755, true)) {
    echo json_encode(['success' => false, 'message' => 'No se pudo crear carpeta de imágenes.']);
    exit;
}

// 6) Borrar foto anterior (si existe)
$stmt_select = $conn->prepare("SELECT foto FROM usuario WHERE id = ? LIMIT 1");
$stmt_select->bind_param("i", $id);
if ($stmt_select->execute()) {
    $result = $stmt_select->get_result();
    if ($result && $result->num_rows === 1) {
        $row = $result->fetch_assoc();
        $oldUrl = $row['foto'];
        if (!empty($oldUrl)) {
            $oldFilename = basename($oldUrl);
            $oldFilepath = $uploadDir . '/' . $oldFilename;
            if (file_exists($oldFilepath)) {
                @unlink($oldFilepath);
            }
        }
    }
}
$stmt_select->close();

// 7) Guardar nueva foto en disco
$filename = 'profile_' . $id . '_' . time() . '.' . $extension;
$filePath = "$uploadDir/$filename";
if (file_put_contents($filePath, $datosImagen) === false) {
    echo json_encode(['success' => false, 'message' => 'Error al guardar la imagen.']);
    exit;
}

// 8) Construir URL pública de la nueva imagen
$baseUrl  = 'http://ec2-51-44-167-78.eu-west-3.compute.amazonaws.com/erocha002/WEB/unigo';
$imageUrl = "$baseUrl/imagenes/$filename";

// 9) Actualizar la URL en la base de datos
$stmt_update = $conn->prepare("UPDATE usuario SET foto = ? WHERE id = ?");
$stmt_update->bind_param("si", $imageUrl, $id);
if ($stmt_update->execute()) {
    echo json_encode([
        'success' => true,
        'message' => 'Imagen subida correctamente.',
        'url'     => $imageUrl
    ]);
} else {
    echo json_encode(['success' => false, 'message' => 'Error al actualizar la BD.']);
}

$stmt_update->close();
$conn->close();
