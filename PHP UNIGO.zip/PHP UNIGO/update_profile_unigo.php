<?php
// update_profile_unigo.php
header('Content-Type: application/json');
require 'db_config_unigo.php';

// 1) Solo POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Método no permitido, usa POST']);
    exit;
}

// 2) Recoger parámetros
$id       = $_POST['id']       ?? '';
$nombre   = trim($_POST['nombre']   ?? '');
$email    = trim($_POST['email']    ?? '');
$telefono = trim($_POST['telefono'] ?? '');

// 3) Validaciones
if (empty($id) || $nombre === '' || $email === '') {
    echo json_encode([
        'success' => false,
        'message' => 'Faltan parámetros (id, nombre o email)'
    ]);
    exit;
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode([
        'success' => false,
        'message' => 'Formato de email inválido'
    ]);
    exit;
}

// 4) Ejecutar UPDATE
$stmt = $conn->prepare("
    UPDATE usuario
       SET nombre   = ?,
           email    = ?,
           telefono = ?
     WHERE id = ?
");
$stmt->bind_param("sssi", $nombre, $email, $telefono, $id);

if ($stmt->execute()) {
    echo json_encode([
        'success' => true,
        'message' => 'Perfil actualizado correctamente'
    ]);
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Error al actualizar perfil'
    ]);
}

$stmt->close();
$conn->close();
